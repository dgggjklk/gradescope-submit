# gradescope-submit
My attempt at converting the rust gradescope-submit crate into a python package
